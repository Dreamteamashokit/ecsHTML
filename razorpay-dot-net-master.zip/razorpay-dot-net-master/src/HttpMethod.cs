﻿using System;

namespace Razorpay.Api
{
    public enum HttpMethod
    {
        Get,
        Post,
        Delete,
        Put,
        Patch,
    }
}
