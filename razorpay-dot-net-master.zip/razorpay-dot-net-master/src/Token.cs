namespace Razorpay.Api
{
    public class Token : Entity
    {
        
    }
}